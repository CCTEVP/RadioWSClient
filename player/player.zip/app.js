let localWs = null;
let localWsReady = false;
let contentId = null;
let contentName = null;
let advertiserId = null;
let advertiserName = null;
let messagesReceived = [{ result: "No messages received" }];
let customPopTimer = null;
let progressBarFill = null;
let loggerElement = null;
let loggerContainer = null;
let loggerTimeout = null;

// Logger function
function log(message, data = null) {
  // Initialize logger elements if not already done
  if (!loggerElement) {
    loggerElement = document.getElementById("logger");
    loggerContainer = document.getElementById("loggerContainer");
  }

  if (!loggerElement || !loggerContainer) return;

  // Format message with timestamp
  const timestamp = new Date().toISOString().split("T")[1].substring(0, 12);
  let logMessage = `[${timestamp}] ${message}`;

  if (data !== null) {
    if (typeof data === "object") {
      logMessage += " " + JSON.stringify(data);
    } else {
      logMessage += " " + data;
    }
  }

  // Add to textarea
  loggerElement.value += logMessage + "\n";
  loggerElement.scrollTop = loggerElement.scrollHeight;

  // Also log to console for debugging
  console.log(message, data !== null ? data : "");

  // Show logger with fade in
  loggerContainer.style.display = "block";
  // Force reflow
  void loggerContainer.offsetWidth;
  loggerContainer.classList.add("show");

  // Clear existing timeout
  if (loggerTimeout) {
    clearTimeout(loggerTimeout);
  }

  // Hide after 5 seconds
  loggerTimeout = setTimeout(() => {
    loggerContainer.classList.remove("show");
    // Wait for fade out transition to complete
    setTimeout(() => {
      loggerContainer.style.display = "none";
    }, 1000);
  }, 5000);
}

// Utility function to safely retrieve a property from BroadSignObject with default value
function getBroadSignProperty(propName, defaultValue) {
  if (
    typeof window.BroadSignObject === "object" &&
    window.BroadSignObject !== null &&
    Object.prototype.hasOwnProperty.call(window.BroadSignObject, propName)
  ) {
    const value = window.BroadSignObject[propName];
    if (typeof value === "string" && value.trim() !== "") {
      const trimmedValue = value.trim();
      log(`[INIT] BroadSignObject.${propName} found:`, trimmedValue);
      return trimmedValue;
    }
    if (value !== null && value !== undefined) {
      log(`[INIT] BroadSignObject.${propName} found:`, value);
      return value;
    }
  }
  return defaultValue;
}

// Get frame_id and ad_copy_id from BroadSignObject or use defaults
const frameId = getBroadSignProperty("frame_id", "12343");
const adCopyId = getBroadSignProperty("ad_copy_id", "1290113894");
const playerId = getBroadSignProperty("player_id", "759244535");
const slotDuration = parseInt(
  getBroadSignProperty("expected_slot_duration_ms", "10000"),
  10
);
const customPopTimeout = slotDuration - 3000; // Reduced slotDuration by 3000ms

log(`[INIT] Slot duration set to ${slotDuration}ms`);
log(
  `[INIT] Custom PoP timeout set to ${customPopTimeout}ms (reduced by 3000ms from original)`
);

// Initialize timer to execute sendCustomPOP based on slotDuration
function startCustomPopTimer() {
  // Clear any existing timer
  if (customPopTimer) {
    clearTimeout(customPopTimer);
  }

  log(`[TIMER] Starting custom POP timer for ${customPopTimeout}ms`);
  customPopTimer = setTimeout(() => {
    log(`[TIMER] Executing sendCustomPOP after ${customPopTimeout}ms`);
    sendCustomPOP();
  }, customPopTimeout);
}

// Progress bar animation
function startProgressBar() {
  if (!progressBarFill) {
    progressBarFill = document.getElementById("progressBarFill");
  }

  if (progressBarFill) {
    // Reset progress bar to 0
    progressBarFill.style.transition = "none";
    progressBarFill.style.width = "0%";

    // Force reflow to apply the reset
    void progressBarFill.offsetWidth;

    // Start animation from 0 to 100% over slotDuration
    progressBarFill.style.transition = `width ${slotDuration}ms linear`;
    progressBarFill.style.width = "100%";

    log(`[PROGRESS] Started progress bar animation for ${slotDuration}ms`);
  }
}

function hideBlueDot() {
  const dot = document.getElementById("customPopDot");
  if (dot) dot.style.opacity = "0";
}

function showBlueDot() {
  const dot = document.getElementById("customPopDot");
  if (dot) dot.style.opacity = "1";
}

function hideRedDot() {
  const dot = document.getElementById("wsDot");
  if (dot) dot.style.opacity = "0";
}

function showRedDot() {
  const dot = document.getElementById("wsDot");
  if (dot) dot.style.opacity = "1";
}
// Simple WebSocket squares highlighter
// Maps incoming payload advertiser.id to a square (1..10)

const WS_URL = "wss://radiowsserver-763503917257.europe-west1.run.app/";
let ws;
let reconnectTimer = null;
let heartbeatTimer = null;
let isManualDisconnect = false;
let connectionStartTime = null;
const RECONNECT_DELAY = 3000; // ms
const HEARTBEAT_INTERVAL = 30000; // 30 seconds
const MAX_RECONNECT_ATTEMPTS = 20; // Allow reconnection for ~1 hour
let reconnectAttempts = 0;

const squaresContainer = document.getElementById("squares");
const squares = squaresContainer
  ? Array.from(squaresContainer.querySelectorAll(".square"))
  : [];
const wsDot = document.getElementById("wsDot");

function connect() {
  if (
    ws &&
    (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)
  ) {
    return;
  }

  try {
    ws = new WebSocket(WS_URL);

    ws.onopen = () => {
      clearTimeout(reconnectTimer);
      log("[WS] Connected");
      hideRedDot();

      // Reset reconnection attempts on successful connection
      reconnectAttempts = 0;
      connectionStartTime = Date.now();

      // Wait for response in onmessage
      // Start heartbeat
      startHeartbeat();

      // Announce presence / broadcast metadata
      announcePresence("player");
    };

    // Handle server ping frames (automatic pong response)
    ws.addEventListener("ping", () => {
      log("[WS] Server ping received, pong sent automatically");
    });

    ws.onmessage = (evt) => {
      // Wait for response in onmessage
      handleMessage(evt.data);
    };

    ws.onerror = (err) => {
      log("[WS] Error", err);
    };

    ws.onclose = () => {
      log("[WS] Closed - will attempt reconnect");

      // Stop heartbeat
      stopHeartbeat();

      // Show connection time if it was established
      if (connectionStartTime) {
        const connectionDuration = Math.round(
          (Date.now() - connectionStartTime) / 1000
        );
        log(`[WS] Connection lasted ${connectionDuration} seconds`);
      }

      showRedDot();

      // Auto-reconnect if not manual disconnect and within attempt limit
      if (!isManualDisconnect && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        scheduleReconnect();
      } else if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
        log("[WS] Maximum reconnection attempts reached");
      }
    };
  } catch (e) {
    log("[WS] Connection exception", e);
    scheduleReconnect();
  }
}

function announcePresence(role) {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;

  const announcement = {
    type: "announce",
    timestamp: new Date().toISOString(),
    clientId: role,
    userAgent: navigator.userAgent,
    screen: {
      width: window.screen?.width || null,
      height: window.screen?.height || null,
    },
    pageVisibility: document.visibilityState,
    location: { href: location.href },
  };

  try {
    ws.send(JSON.stringify(announcement));
    log("[WS] Announce sent", announcement);
  } catch (e) {
    log("[WS] Failed to send announce", e);
  }
}

function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectAttempts++;

  const delay = RECONNECT_DELAY * Math.min(reconnectAttempts, 5); // Exponential backoff, max 15s
  log(
    `[WS] Reconnection attempt ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS} in ${
      delay / 1000
    }s...`
  );

  reconnectTimer = setTimeout(() => {
    if (!isManualDisconnect && reconnectAttempts <= MAX_RECONNECT_ATTEMPTS) {
      connect();
    }
  }, delay);
}

function handleMessage(raw) {
  let data;
  try {
    data = JSON.parse(raw);
  } catch (e) {
    log("[WS] Non-JSON message ignored", raw);
    return;
  }

  // Handle different message types from server
  if (data.type === "welcome") {
    log(`[WS] Server welcome: ${data.message}`);
    return;
  }

  // Handle broadcast messages (server wraps client messages in broadcast envelope)
  if (data.type === "broadcast") {
    log(`[WS] Broadcast from ${data.from}`);
    // Extract the actual payload from the broadcast wrapper
    data = data.data;
  }
  // Only process messages where the (unwrapped) type is 'post'
  if (!data || data.type !== "post") {
    // Silently ignore other types (could log if needed)
    return;
  }

  // Expected structure now:
  // {
  //   "type": "post",
  //   "timestamp": "...",
  //   "data": { "advertiser": { "id": "1" | 1, ... }, ... }
  // }
  // Save the timestamp from the post message before accessing nested data
  const messageTimestamp = data.timestamp;
  const payload = data.data;
  if (!payload) {
    log("[WS] 'post' message missing data payload", data);
    return;
  }

  // Locate advertiser object (direct or nested one level deep)
  let core = payload;
  if (core && typeof core === "object" && !core.advertiser) {
    for (const k in core) {
      if (core[k] && typeof core[k] === "object" && core[k].advertiser) {
        core = core[k];
        break;
      }
    }
  }

  if (!core || !core.advertiser || !core.advertiser.id) {
    log("[WS] 'post' payload missing advertiser.id", data);
    return;
  }

  // Convert advertiser id string to integer for highlighting
  const advertiserIdValue = parseInt(core.advertiser.id, 10);
  if (!Number.isInteger(advertiserIdValue)) {
    log("[WS] advertiser.id not a valid integer", core.advertiser.id);
    return;
  }

  // Store received data in messagesReceived array
  messagesReceived.push({
    t: messageTimestamp || new Date().toISOString(),
    r: new Date().toISOString(),
    a: {
      i: core.advertiser.id,
      n: core.advertiser.name,
    },
    c: {
      i: core.content.id,
      n: core.content.name,
    },
  });
  log(
    "[WS] Message stored in messagesReceived array. Total messages:",
    messagesReceived.length
  );
  log("[WS] Current messagesReceived:", messagesReceived);

  // Update global variables with post message data
  advertiserId = core.advertiser.id;
  advertiserName = core.advertiser.name;
  contentId = core.content.id;
  contentName = core.content.name;

  log("[WS] Post data updated:", {
    advertiserId,
    advertiserName,
    contentId,
    contentName,
  });

  log(
    `[WS] Highlighting square for advertiser ID (post): ${advertiserIdValue}`
  );
  highlightSquare(advertiserIdValue);

  // Update Now Playing display
  updateNowPlaying(contentName, advertiserName);
}

// Local WebSocket logic for sending custom payload after highlight
function sendCustomPOP() {
  const LOCAL_WS_URL = "ws://localhost:2326";

  // Build flattened custom_field JSON with current post data
  const customFieldData = {
    player_id: playerId,
    frame_id: frameId,
  };

  // Flatten messages array into individual properties (m1_, m2_, etc.)
  messagesReceived.forEach((msg, index) => {
    const prefix = `m${index + 1}_`;
    customFieldData[`${prefix}t`] = msg.t || "";
    customFieldData[`${prefix}r`] = msg.r || "";
    customFieldData[`${prefix}a_id`] = msg.a?.i || "";
    customFieldData[`${prefix}a_name`] = msg.a?.n || "";
    customFieldData[`${prefix}c_id`] = msg.c?.i || "";
    customFieldData[`${prefix}c_name`] = msg.c?.n || "";
  });

  const PAYLOAD = {
    rc: {
      version: "1",
      id: "1",
      action: "custom_pop",
      frame_id: frameId,
      content_id: adCopyId,
      external_value_1: "RADIO CONTENT ACTIVATED",
      external_value_2: JSON.stringify(customFieldData),
      name: "RADIO CONTENT",
    },
  };

  log("[LocalWS] Preparing to send custom_pop payload:", PAYLOAD);
  // Show blue dot when sending custom_pop
  showBlueDot();

  // If already open, just send
  if (localWs && localWs.readyState === WebSocket.OPEN) {
    try {
      localWs.send(JSON.stringify(PAYLOAD));
      log("[LocalWS] Sent Custom POP");
    } catch (e) {
      log("[LocalWS] Failed to send Custom POP", e);
    }
    return;
  }

  // If not open, create and send on open
  try {
    localWs = new WebSocket(LOCAL_WS_URL);
    localWs.onopen = function () {
      try {
        localWs.send(JSON.stringify(PAYLOAD));
        log("[LocalWS] Sent custom payload (on open)");
      } catch (e) {
        log("[LocalWS] Failed to send payload (on open)", e);
      }
    };
    localWs.onmessage = function (event) {
      try {
        const resp = JSON.parse(event.data);
        log("[LocalWS] Response received:", resp);

        // Check for successful custom_pop response
        if (
          resp &&
          resp.rc &&
          resp.rc.action === "custom_pop" &&
          resp.rc.status === "1"
        ) {
          hideBlueDot();
          log("[LocalWS] CustomPOP success, blue dot hidden");
        }
      } catch (e) {
        log("[LocalWS] Failed to parse response", e);
      }
    };
    localWs.onerror = function (err) {
      log("[LocalWS] Error", err);
    };
    localWs.onclose = function () {
      log("[LocalWS] Connection closed");
      // Optionally, set localWs to null to allow reconnect on next trigger
      localWs = null;
    };
  } catch (e) {
    log("[LocalWS] Exception opening local ws", e);
  }
}

let nowPlayingTimeout = null;

function updateNowPlaying(content, advertiser) {
  const nowPlayingContentElement = document.getElementById("nowPlayingContent");
  const nowPlayingAdvertiserElement = document.getElementById(
    "nowPlayingAdvertiser"
  );
  const nowPlayingContainer = document.getElementById("nowPlayingContainer");
  if (nowPlayingContentElement && content) {
    nowPlayingContentElement.textContent = content;
    nowPlayingAdvertiserElement.textContent = advertiser;
    if (nowPlayingContainer) {
      // Clear any existing timeout
      if (nowPlayingTimeout) {
        clearTimeout(nowPlayingTimeout);
      }

      // Show the container and remove fade-out class
      nowPlayingContainer.style.display = "block";
      nowPlayingContainer.classList.remove("fade-out");

      // Schedule fade-out after 10 seconds
      nowPlayingTimeout = setTimeout(() => {
        nowPlayingContainer.classList.add("fade-out");
        // Hide completely after transition completes (0.5s)
        setTimeout(() => {
          nowPlayingContainer.style.display = "none";
        }, 500);
      }, 10000);
    }
    log("[UI] Now Playing updated:", content, advertiser);
  }
}

function highlightSquare(id) {
  // id 1 maps to index 0, etc.
  if (id < 1 || id > squares.length) {
    log("Advertiser id out of range (1.." + squares.length + "):", id);
    return;
  }

  // Clear existing active state
  squares.forEach((sq) => sq.classList.remove("active"));

  const target = squares[id - 1];
  if (!target) return;

  target.classList.add("active");
  target.classList.remove("pulse");
  // retrigger pulse animation
  void target.offsetWidth; // force reflow
  target.classList.add("pulse");
}

function startHeartbeat() {
  stopHeartbeat(); // Clear any existing heartbeat

  // Send lightweight keepalive messages (server handles native ping/pong)
  heartbeatTimer = setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      try {
        // Send a lightweight keepalive message
        const keepAlive = JSON.stringify({
          type: "keepalive",
          timestamp: new Date().toISOString(),
          clientId: "player",
        });
        ws.send(keepAlive);
        log("[WS] Keepalive sent");
      } catch (error) {
        log(`[WS] Failed to send keepalive: ${error.message}`);
      }
    }
  }, HEARTBEAT_INTERVAL);
}

function stopHeartbeat() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
}

// Add disconnect function for manual disconnection
function disconnect() {
  if (ws) {
    isManualDisconnect = true;
    stopHeartbeat();
    clearTimeout(reconnectTimer);
    ws.close(1000, "User initiated disconnect");
    ws = null;
    connectionStartTime = null;

    // Reset manual disconnect flag after a delay
    setTimeout(() => {
      isManualDisconnect = false;
    }, 1000);
  }
}

// Expose a manual trigger similar to BroadSignPlay style if needed
function BroadSignPlay() {
  isManualDisconnect = false;
  reconnectAttempts = 0;
  connect();

  // Start progress bar animation when BroadSignPlay is executed
  startProgressBar();

  // Start custom POP timer when BroadSignPlay is executed
  startCustomPopTimer();
}
window.BroadSignPlay = BroadSignPlay;
window.disconnect = disconnect;

// Auto-connect on page load
window.addEventListener("load", () => {
  log("[INIT] Page loaded - auto-connecting to WebSocket");
  BroadSignPlay();
});
